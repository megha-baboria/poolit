# SoC_Pool_It
SoC 2020, Pool It!
