from django.db import models
from django.utils.text import slugify
from django.urls import reverse
from django.contrib.auth import get_user_model
User=get_user_model()
import random

def random_string():
    return str(random.randint(10000, 99999))
# from django import template
# register=template.Library()



class Group(models.Model):
    name=models.CharField(max_length=250,unique=True)
    hash=models.CharField(default = random_string)
    description=models.TextField(blank=True,default='')
    members=models.ManyToManyField(User,related_name='participation',through="Groupmember")

    def __str__(self):
        return self.name

    def save(self,*args,**kwargs):
        self.slug=slugify(self.name)
        super().save(*args,**kwargs)

    def get_absolute_url(self):
        return reverse("groups:single", kwargs={"slug": self.slug})
    
    class Meta:
        ordering =['name']


class Groupmember(models.Model):
    group=models.ForeignKey(Group,related_name='membership',on_delete=models.CASCADE)
    user=models.ForeignKey(User,related_name='user_groups',on_delete=models.CASCADE)

    def __str__(self):
        return self.user.username
    
    class Meta:
        unique_together=('group','user')

