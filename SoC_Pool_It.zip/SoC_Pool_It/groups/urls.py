from django.urls import path
from .views import Creategroup,Singlegroup
app_name='groups'
urlpatterns = [
    
   path('new/',Creategroup.as_view(),name="create"),
   path('<slug>/',Singlegroup.as_view(),name="single"),

]